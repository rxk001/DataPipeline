from setuptools import setup

setup(
    name='DataPipeline',
    version='',
    packages=['Utils'],
    url='',
    license='',
    author='rxk00',
    author_email='',
    description=''
)
